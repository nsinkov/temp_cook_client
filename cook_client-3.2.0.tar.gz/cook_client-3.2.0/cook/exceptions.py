class CookRetriableException(Exception):
    pass
